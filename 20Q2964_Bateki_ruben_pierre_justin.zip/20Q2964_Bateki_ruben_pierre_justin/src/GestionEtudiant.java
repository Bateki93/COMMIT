    import java.util.Scanner;

    public class GestionEtudiant{
  

        public static int taille(){
            System.out.println("Entrez le nombre d'etudiant ");
            Scanner nc = new Scanner(System.in);
            int n = nc.nextInt();
            return n;
        }
              
//Entrer les etudiant ds le table
        public static Etudiant[] Entre(int n){

            Etudiant[] tab = new Etudiant[n];
            for(int j = 0 ; j < n ; j ++){
                tab[j] =  Etudiant.createEtudiant();
            }
                return tab;
        }
           
           
//foction qui trie le tableau
    static void Trie(int n, Etudiant[] tab){

        int j , i ;
        Etudiant tempon ;

        for(j = 0 ; j < n ; j++){
            for(i = j+1 ; i < n ; i++){
                if(tab[j].getMoyenne() > tab[i].getMoyenne()){

                    tempon = tab[j];
                    tab[j] = tab[i];
                    tab[i]= tempon;
                }
            }
        }
    }
//fonction qui affiche les etudiant par ordre de merite
    static <tab> void Merite(int n, Etudiant[] tab){
        for(int i = 0 ; i < n ; i++){


          System.out.println(tab[i].getNom());

        }
    }

        //fonction qui affiche le dernier etudiant
    static void Dernier(int n,Etudiant[] tab){
         tab[n].afficher();
    }

   static void reinitialiser(Etudiant[] tab){
       tab =null ;
       System.out.println("reinitialication effectue");
    }
        //fonction qui affiche le premier etudiant
        static void Premier(int n,Etudiant[] tab){
            tab[0].afficher();
        }

    static void Sortir(){
        System.exit(0);
    }
}