import java.util.Scanner;

public class Main{

        public static void main(String[] args){

    int choice;
            int n = GestionEtudiant.taille();

            Etudiant[] etudiant = GestionEtudiant.Entre(n);

            System.out.println("1 - Afficher Les Etudiants par Ordre de Merite");
            System.out.println("2 - Afficher Les informations du Premmier Etudiants");
            System.out.println("3 - Afficher Les informations du Dernier Etudiant");
            System.out.println("4 - Reinitialiser la Liste de la Classe");
            System.out.println("5 -  Sortir du Programme");

            System.out.println("viellz faire ub choix:");
            Scanner clavier =new Scanner(System.in);
            choice=clavier.nextInt();
            switch(choice){
                case 1 :
                    GestionEtudiant.Trie(n,etudiant);
                    GestionEtudiant.Merite(n,etudiant);
                break;

                case 2 :
                    GestionEtudiant.Trie(n,etudiant);
                GestionEtudiant.Premier(n,etudiant);
                break;

                case 3 :
                    GestionEtudiant.Trie(n,etudiant);
                GestionEtudiant.Dernier(n,etudiant);
                break;

                case 4:
                   GestionEtudiant.reinitialiser(etudiant);
                break;

                case 5:
                GestionEtudiant.Sortir();
                break;


            }
                }





    }
